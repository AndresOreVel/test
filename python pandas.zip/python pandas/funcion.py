def nombre_de_la_funcion(parametro1, parametro2):
    # Cuerpo de la función
    # Puedes realizar acciones y cálculos aquí
    # Puedes usar los parámetros para procesar datos
    print(parametro1)
    print(parametro2)
    # Opcionalmente, puedes devolver un valor usando la palabra clave 'return'
    return 3


print("Hola funcion!")

ret = nombre_de_la_funcion("param1", "param2")

print(ret)
