# Demana a l'usuari que introdueixi el seu nom
# nom = input("Introdueix el teu nom: ") #python3
nom = raw_input("Introdueix el teu nom: ")  # python 2

# Saluda l'usuari amb el seu nom
print("Hola,", nom)
