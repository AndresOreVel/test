# Obre un fitxer en mode d'escriptura ('w')
with open('fitxer.txt', 'w') as fitxer:
    fitxer.write("Escribint a fitxer \n")
    fitxer.write("segona linia! \n")

print("Dades escrites correctament al fitxer.")
