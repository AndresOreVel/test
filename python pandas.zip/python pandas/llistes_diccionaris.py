mi_lista = [1, 2, 3, "cuatro", "cinco"]

print(mi_lista[0])  # Imprime el primer elemento (1)
mi_lista[0] = 20   # Modifica el segundo elemento (2) por 20
print(mi_lista[0])  # Imprime el primer elemento (1)


mi_diccionario = {"nombre": "Juan", "edad": 30, "ciudad": "Barcelona"}
# Imprime el valor asociado a la clave "nombre" (Juan)
print(mi_diccionario["nombre"])
mi_diccionario["edad"] = 31  # modifica
mi_diccionario["idioma"] = "catala"  # afegeix
