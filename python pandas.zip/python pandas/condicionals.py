numero = 10  # Pots canviar aquest valor per provar diferents situacions

if numero > 0:
    print("nombre positiu")
elif numero < 0:
    print("nombre negatiu")
else:
    print("nombre es 0")
